"""Persistent, fail-fast continuation of the existing frozen EuroSAT workflow."""
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import traceback

operation=Path(sys.argv[1]).resolve()
preflight=json.loads((operation/'preflight.json').read_text())
root=operation.parent.parent
base=root.parent.parent
record_path=operation/'pipeline.json'
status_path=base.parent/'PROJECT_STATUS.md'
stages=['final-train','seal','evaluate','report']
commands={stage:[sys.executable,'-u',str(base/'diagnostic_workflow.py'),'workflow',stage,
    '--data-dir',str(base.parent/'EuroSAT_RGB'),'--output',str(root),'--device','cuda']
    +(['--restart-incomplete'] if stage=='final-train' else []) for stage in stages}
record=dict(launched_utc=datetime.now(timezone.utc).isoformat(),pipeline_state='starting',
    supervisor_pid=os.getpid(),session_id=os.getsid(0),process_group_id=os.getpgrp(),
    boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
    current_stage='initializing',stage_state='starting',stage_results={},
    final_training_completed=preflight['final_completed'],test_evaluations_completed=0,
    stage_logs={s:str(operation/(s+'.log')) for s in stages},
    record_path=str(record_path),preflight_path=str(operation/'preflight.json'),
    controller_path=str(Path(__file__).resolve()),commands=commands,
    master_log=str(operation/'pipeline.log'),exit_code_path=str(operation/'pipeline.exitcode'),
    output_root=str(root),working_directory=str(base),retry_policy='no retries; stop at first error')
interrupted=False
child=None

def on_interrupt(signum,frame):
    global interrupted
    interrupted=True
signal.signal(signal.SIGINT,on_interrupt)

def now():return datetime.now(timezone.utc).isoformat()
def digest(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def fingerprint(value):return hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()

def progress():
    trained=evaluated=0
    for run in preflight['final_run_ids']:
        directory=root/'runs'/run
        if (directory/'completion.json').exists() and json.loads((directory/'status.json').read_text())['status']=='completed':trained+=1
        if (directory/'test_metrics.json').exists():evaluated+=1
    return trained,evaluated

def publish(state):
    record['stage_state']=state;record['updated_utc']=now()
    trained,evaluated=progress();record.update(final_training_completed=trained,test_evaluations_completed=evaluated)
    temp=record_path.with_suffix('.json.tmp');temp.write_text(json.dumps(record,indent=2)+'\n');temp.replace(record_path)
    text=status_path.read_text()
    text=re.sub(r'^- Authorized final pipeline:.*$',f"- Authorized final pipeline: **{record['pipeline_state']}**, stage **{record['current_stage']} ({state})**; final training {trained}/680, test evaluation {evaluated}/680. See the current lifecycle record below.",text,flags=re.M)
    begin='<!-- final-pipeline:start -->';end='<!-- final-pipeline:end -->'
    lines=[begin,'## Current final pipeline after reboot','',
        f"- State: **{record['pipeline_state']}**, stage **{record['current_stage']} ({state})**; updated UTC {record['updated_utc']}.",
        f'- Final training: **{trained}/680 complete**; **{680-trained} remain**; test evaluation **{evaluated}/680 complete**.',
        f"- Supervisor PID / session / process group: **{os.getpid()}**; workflow PID: `{record.get('workflow_pid','pending')}`.",
        f'- Process/state record: `{record_path}`.',
        f"- Controller and preflight: `{operation/'controller.py'}`, `{operation/'preflight.json'}` (preserved across reboots).",
        f"- Lifecycle log / exit code: `{operation/'pipeline.log'}`, `{operation/'pipeline.exitcode'}`.",
        '- Detached session; continues independently of the chat, but a full laptop reboot terminates it.',
        '- Same environment, CUDA, dataset, frozen selections/protocol, with existing numerical diagnostic hooks. No automatic retries.',
        '- Stage order: final-train → verified seal → evaluate → report, without --limit. The reboot-interrupted run is archived and restarted through --restart-incomplete.',
        '- Sealing requires all 680 completed training records/checkpoint hashes and finite histories; report requires all 680 evaluations.','',
        '| Stage | State | Exit | Log |','|---|---|---|---|']
    for stage in stages:
        item=record['stage_results'].get(stage,{})
        lines.append(f"| {stage} | {item.get('state','pending')} | {item.get('exit_code','pending')} | `{record['stage_logs'][stage]}` |")
    lines.extend(['','Progress and safe stop:','','```bash',f"cat '{record_path}'",f"tail -f '{record['stage_logs'].get(record['current_stage'],str(operation/'pipeline.log'))}'",f'kill -INT -- -{os.getpid()}','```','',
        'Wait for cleanup after SIGINT; completed results remain reusable.',
        f"Final outputs: `{root/'final_plan.json'}`, `{root/'results.csv'}`, `{root/'runs'}` (per-model evidence and test predictions), `{root/'generated'}` (reports, tables, figures and provenance).",end])
    block='\n'.join(lines)
    if begin in text:
        a=text.index(begin);b=text.index(end)+len(end);text=text[:a]+block+text[b:]
    else:text=text.rstrip()+'\n\n'+block+'\n'
    status_path.write_text(text)
    print(json.dumps({'utc':record['updated_utc'],'state':record['pipeline_state'],'stage':record['current_stage'],'stage_state':state,'final_completed':trained,'test_completed':evaluated}),flush=True)

def verify_controls():
    for path,expected in preflight['protected_shared_files'].items():
        if digest(path)!=expected:raise ValueError('Frozen shared input changed: '+path)
    for name,expected in preflight['original_source_hashes'].items():
        if digest(base/name)!=expected:raise ValueError('Frozen CORE source changed: '+name)

def gate(stage):
    verify_controls();trained,evaluated=progress()
    if stage=='seal':
        if trained!=680 or evaluated:raise ValueError('Seal requires 680 completed trainings and no test access')
        for run in preflight['final_run_ids']:
            directory=root/'runs'/run;receipt=json.loads((directory/'completion.json').read_text())
            for name,expected in receipt['sha256'].items():
                if digest(directory/name)!=expected:raise ValueError('Final completion checksum mismatch: '+str(directory/name))
            with (directory/'history.csv').open() as stream:history=list(csv.DictReader(stream))
            if not history or not all(math.isfinite(float(v)) for row in history for v in row.values()):raise ValueError('Invalid final history: '+run)
            metrics=json.loads((directory/'best_validation_metrics.json').read_text())
            if not all(math.isfinite(metrics[k]) for k in ['loss','accuracy','macro_f1','balanced_accuracy']):raise ValueError('Invalid final metrics: '+run)
        record['final_completion_checksums_verified']=680
    if stage=='evaluate':
        plan=json.loads((root/'final_plan.json').read_text())
        if trained!=680 or plan['n']!=680 or plan['run_ids']!=preflight['final_run_ids'] or plan['protocol_hash']!=preflight['protocol_hash']:raise ValueError('Invalid sealed final plan')
        for key,name in [('gn_selection_hash','gn_selection.json'),('loss_selection_hash','loss_selection.json')]:
            if plan[key]!=fingerprint(json.loads((root/name).read_text())):raise ValueError('Sealed selection mismatch')
    if stage=='report' and (trained!=680 or evaluated!=680):raise ValueError('All 680 evaluations required before report')

exit_code=1
try:
    for stage in stages:
        if interrupted:raise InterruptedError('Pipeline interrupted')
        record.update(pipeline_state='running',current_stage=stage,workflow_pid=None)
        record['stage_results'][stage]={'state':'verifying','started_utc':now()};publish('verifying')
        gate(stage)
        if interrupted:raise InterruptedError('Pipeline interrupted')
        record['stage_results'][stage]['state']='running';publish('running')
        with Path(record['stage_logs'][stage]).open('x') as output:
            child=subprocess.Popen(commands[stage],cwd=base,stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT)
            record['workflow_pid']=child.pid;publish('running')
            code=child.wait()
        record['stage_results'][stage].update(exit_code=code,finished_utc=now())
        if code!=0:raise RuntimeError(f'{stage} failed with exit code {code}')
        verify_controls()
        if stage=='evaluate' and progress()[1]!=680:raise ValueError('Evaluate exited without all final metrics')
        if stage=='report':
            for path,expected in preflight['protected_existing_run_files'].items():
                if digest(path)!=expected:raise ValueError('Existing completed run changed: '+path)
            for name in ['summary.csv','seed_level_results.csv','per_client_results.csv','table1.tex','table2.tex','table3.tex','figure1.pdf','figure2.pdf','figure3.pdf','figure4.pdf','interpretations.md','provenance.json']:
                if not (root/'generated'/name).is_file():raise ValueError('Missing report output: '+name)
        record['stage_results'][stage]['state']='completed';publish('completed')
    record.update(pipeline_state='completed',finished_utc=now(),exit_code=0);exit_code=0;publish('completed')
except BaseException as error:
    traceback.print_exc()
    if child is not None and child.poll() is None:
        os.killpg(os.getpgrp(),signal.SIGINT)
        child.wait()
    exit_code=130 if interrupted else 1
    record.update(pipeline_state='interrupted' if interrupted else 'failed',error=repr(error),finished_utc=now(),exit_code=exit_code)
    if record['current_stage'] in record['stage_results']:
        record['stage_results'][record['current_stage']].update(state=record['pipeline_state'],error=repr(error))
    publish(record['pipeline_state'])
finally:
    (operation/'pipeline.exitcode').write_text(str(exit_code)+'\n')
raise SystemExit(exit_code)
